package daviSousaSoares;

public class DadosInvalidos extends Exception {
	public DadosInvalidos() {
		super("dados invalidos");
	}
}
