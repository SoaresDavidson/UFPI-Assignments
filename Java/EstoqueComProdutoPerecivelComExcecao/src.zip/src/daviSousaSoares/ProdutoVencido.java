package daviSousaSoares;

public class ProdutoVencido extends Exception {
	public ProdutoVencido() {
		super("Produto Vencido!");
	}
}
