package daviSousaSoares.estoque;

import java.util.Date;

public class UsoEstoque {
}
