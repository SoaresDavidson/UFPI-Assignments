package daviSousaSoares;

import java.util.Date;

public class UsoEstoque {
}
