package daviSousaSoares.banco;

public abstract class EstruturaDeDadosDeContas {

	public abstract void cadastrar(Conta c);
		
	public abstract Conta pesquisar(int num);
}
