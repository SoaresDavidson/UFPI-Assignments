package daviSousaSoares.estoqueComProdutoPerecivel;

import java.util.Date;

public class UsoEstoque {
}
